var cellSize=25;
var mario;
// fireball vars
var shot;
var shot2;
var shot3;
var shot4;
var shot5;

var score;

var myVar;

function setup()
{
  createCanvas(800,600);
  frameRate(9);
  //background(120);



  mario = new Head(cellSize * 2, cellSize * 2, 180, cellSize);

  shot = new shooters(800,10, 100);
  shot1 = new shooters(800,100,200);
  shot2 = new shooters(800,200,300);
  shot3 = new shooters(800,300,400);
  shot4 = new shooters(800,400,500);
  shot5 = new shooters(800,500,550);

  score = new Score();


}

function draw()
{
  background(120);
  //drawGrid();

  score.display();

  mario.display();
  mario.move();

  score +=1;

  text("Score:" +int(score), 50, 50);



  drawFireballs();

//  myVar = setInterval(drawFireballs, 5000);

  //arr.push(new shooters());
  //drawFireballs();

//  if (mario.intersect(shooters))
  //{
    //end game
    //print score
//  }


}

function drawFireballs()
{

  shot.display();
  shot.move();

  shot1.display();
  shot1.move();

  shot2.display();
  shot2.move();

  shot3.display();
  shot3.move();

  shot4.display();
  shot4.move();

  shot5.display();
  shot5.move();
}



function keyPressed()
{
  if (key=='w')
  {

    mario.direction =0;
  }

  else if (key=='a')
  {
    mario.direction =270;
  }
  else if (key=='s')
  {
    mario.direction =180;
  }
  else if (key=='d')
  {
    mario.direction =90;
  }
}
