var cellSize=25;
var mario;

// fireball vars
var shot;
var shot2;
var shot3;
var shot4;
var shot5;

var score;
var scorelabel;

var liveslabel;
var lives = 100;


var myVar;

function playAgain()
{
  score = 0;
  lives = 100;
  setup();
  draw();
}

function setup()
{
  createCanvas(800,600);
  frameRate(9);
  //background(120);



  mario = new Head(cellSize * 2, cellSize * 2, 270, cellSize);

  shot = new shooters(800,10, 100);
  shot1 = new shooters(800,100,200);
  shot2 = new shooters(800,200,300);
  shot3 = new shooters(800,300,400);
  shot4 = new shooters(800,400,500);
  shot5 = new shooters(800,500,550);



}

function draw()
{


  background(120);
  //drawGrid();
  var backgroundimg = new Image(100, 200);
  backgroundimg.src = './images/sky.jpg';
  var c = document.getElementById("defaultCanvas0");
  var ctx = c.getContext("2d");
  ctx.drawImage(backgroundimg, 0, 0, 800, 700);


  mario.display();
  mario.move();

  score +=10;

  textSize(18);
  textStyle(BOLD);
  scorelabel = text("Score: " +int(score), 0, 20);
  scorelabel.fill(255,255,255);

 if (mario.intersect(shot) || mario.intersect(shot1) || mario.intersect(shot2) || mario.intersect(shot3) || mario.intersect(shot4) || mario.intersect(shot5))
  {
    lives-=8;
    //scorelabel = text("Score: " +int(score), 0, 20);

  //  console.log("hit---draw");
  }



  liveslabel = text("HP: " + lives, 640, 20);

  drawFireballs();


   if(lives == 0 || lives < 0)
  {

    resizeCanvas(800,800);
    var gameover = new Image(100, 200);
    gameover.src = './images/gameover.png';
    var d = document.getElementById("defaultCanvas0");
    var dtx = d.getContext("2d");
    dtx.drawImage(gameover, 0,0, 800, 700);

    score -=10;

    textSize(30);
    textStyle(BOLD);
    var end = text(score, 435, 110);
    end.fill(255,255,255);

    textSize(30);
    textStyle(BOLD);
    var button = "Play Again?";


    replay = createButton(button);
    replay.size(200,100);
    replay.position(300,580);
  //  replay.fill(255,255,255);
    //replay.mousePressed(Program.restart());
    //end.color(250,0,0);

  }
}

function drawFireballs()
{

  shot.display();
  shot.move();

  shot1.display();
  shot1.move();

  shot2.display();
  shot2.move();

  shot3.display();
  shot3.move();

  shot4.display();
  shot4.move();

  shot5.display();
  shot5.move();
}



function keyPressed()
{
  if (key=='w')
  {

    mario.direction =0;
  }

  else if (key=='a')
  {
    mario.direction =270;
  }
  else if (key=='s')
  {
    mario.direction =180;
  }
  else if (key=='d')
  {
    mario.direction =90;
  }
}
